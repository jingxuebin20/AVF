import os
import itertools
import torch
import torch.nn as nn

from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
from parsers import get_args
from trainer import train_model, evaluate_model
from utils import init_weights, keras_lr_decay
from data_preprocess import devset_gen, evalset_gen, eval_trial_txt, cat_t_paths
from model import *
from loss import * 

os.environ['CUDA_VISIBLE_DEVICES']='6'
'''
######      model训练模块     ######
'''
def main():
    ##  1、解析参数
    args = get_args()
    ##  2、device setting
    cuda = torch.cuda.is_available()
    device = torch.device('cuda' if cuda else 'cpu')
    print('Device: {}'.format(device))
    ##  3、通过设定一个固定的随机种子,使实验可重复进行
    if args.reproducible:
        torch.manual_seed(args.seed)
        np.random.seed(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    ##  4、设置模型和参数结果的保存路径
    save_dir = args.save_dir
    # 如果路径不存在，则先创建
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    if not os.path.exists(save_dir+'results/'):
        os.makedirs(save_dir+'results/')
    if not os.path.exists(save_dir+'models/'):
        os.makedirs(save_dir+'models/')
    if not os.path.exists(save_dir+'pre-trained_model/'):
        os.makedirs(save_dir+'pre-trained_model/')

    ##  6、设置目标函数
    AAMsoftmax_net = AAMsoftmaxloss(feature_dim=512, cls_num=args.model['nb_classes'], margin=0.1, scale=60).to(device)
    AMsoftmax_net = AMsoftmaxloss(feature_dim=512, cls_num=args.model['nb_classes'], margin=0.1, scale=80).to(device)
    Centerloss_net = CenterLoss(feature_dim=512, cls_num=args.model['nb_classes']).to(device)
    # AAMsoftmax_net = AAMsoftmaxloss(feature_dim=192, cls_num=args.model['nb_classes'], margin=0.1, scale=60).to(device)
    # AMsoftmax_net = AMsoftmaxloss(feature_dim=192, cls_num=args.model['nb_classes'], margin=0.1, scale=80).to(device)
    # Centerloss_net = CenterLoss(feature_dim=192, cls_num=args.model['nb_classes']).to(device)
    ##  7、生成一个字典来存储各类评估准则
    criterion = {}
    criterion['CE_loss'] = nn.CrossEntropyLoss()  # 选用交叉熵损失函数
    criterion['AAMsoftmax_loss'] = AAMsoftmax_net
    criterion['AMsoftmax_loss'] = AMsoftmax_net
    criterion['Center_loss'] = Centerloss_net

######      Training Model     ######
    ##  【1】、初始化model
    # model = Gated_Feature_Fusion(args.model).to(device)       # Gated Multimodal Fusion Network
    # model = Gated_all_Feature_Fusion(args.model).to(device)
    # model = Attention_Feature_Fusion(args.model).to(device)   # Attention Multi-modal Fusion Network
    # model = Concat_Feature_Fusion(args.model).to(device)      # Concatenate + FCs Fusion Network
    # model = Inter_Attention_Feature_Fusion(args.model).to(device)
    model = Only_Fcae_Feature(args.model).to(device)
    # model = Only_Voice_Feature(args.model).to(device)

    if args.load_model:
        model.load_state_dict(torch.load(args.load_model_dir))
        print('加载 {} 预训练模型，继续训练！'.format(args.load_model_dir))
    nb_params = sum([param.view(-1).size()[0] for param in model.parameters()])
    print('参数总量为: {}'.format(nb_params))
    if not args.load_model:
        model.apply(init_weights)
    ##  【2】、optimizer设置
    if args.optimizer.lower() == 'adam':
        optimizer = torch.optim.Adam(itertools.chain( model.parameters(),
            AAMsoftmax_net.parameters(), AMsoftmax_net.parameters(), Centerloss_net.parameters() ),
            lr=args.lr, weight_decay=args.weight_decay, amsgrad=args.amsgrad)
    elif args.optimizer.lower() == 'sgd':
        optimizer = torch.optim.SGD(itertools.chain(model.parameters()), lr=args.lr, momentum=args.opt_mom,
                                    weight_decay=args.weight_decay, nesterov=args.nesterov)
    else:
        raise NotImplementedError('Add other optimizers if needed')
    #   如果有训练好的模型，则可以直接导入optimizer
    if args.load_model:
        optimizer.load_state_dict(torch.load(args.load_model_opt_dir))    # args.load_model_opt_dir 为optimizer参数的保存路径
    ##  【3】、设定学习率衰减
    if bool(args.do_lr_decay):
        if args.lr_decay == 'keras':
            lr_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda = lambda step: keras_lr_decay(step))
        elif args.lr_decay == 'cosine':
            raise NotImplementedError('Not implemented yet')
        else:
            raise NotImplementedError('Not implemented yet')
    ##  【4】、开始分epoch进行训练
    best_eval_eer = 99.
    f_eer = open(save_dir + 'Eval_EER.txt', 'a', buffering=1)   # buffering设置为1时，表示在文本模式下使用行缓冲区
    tb_writer = SummaryWriter('./log')
    for epoch in tqdm(range(args.epoch)):
        train_model(model = model, devset_gen = devset_gen, optimizer = optimizer, lr_scheduler = lr_scheduler, criterion = criterion, epoch = epoch, device = device, args = args)
        eval_eer,eval_minDCF = evaluate_model(model = model,evalset_gen = evalset_gen, eval_trial_txt = eval_trial_txt, cat_paths = cat_t_paths, save_dir = save_dir,epoch = epoch,device = device)
        # 将当前epoch的eval_eer结果实时保存起来
        tb_writer.add_scalars('Evaluation', {'EER': eval_eer}, epoch)
        f_eer.write('epoch:%d, eval_eer:%.4f \n' % (epoch, eval_eer))
        # 若当目前epoch的最新EER值低于之前最好的EER，则更新，EER越小越好
        if float(eval_eer) < best_eval_eer:
            best_eval_eer = float(eval_eer)
            print('New best EER: %f' % float(eval_eer))
            torch.save(model.state_dict(), save_dir+'models/epoch%d_%.4f.pt'%(epoch, eval_eer) )
            torch.save(optimizer.state_dict(), save_dir+'models/best_optimizer_eval.pt')
            torch.save(model,save_dir+"pre-trained_model/best_model.pkl")
    f_eer.close()

if __name__ == '__main__':
    main()
