import torch
import numpy as np
from tqdm import tqdm
from torch.utils.tensorboard import SummaryWriter
from sklearn.metrics import roc_curve
from scipy.optimize import brentq
from scipy.interpolate import interp1d
from utils import cos_sim,ComputeMinDcf,tuneThresholdfromScore,ComputeErrorRates

def train_model(model, devset_gen, optimizer, lr_scheduler, criterion, epoch, device, args):
    model.train()
    tb_writer = SummaryWriter('./log')
    f_loss = open('DNNs/Train_Loss.txt', 'a', buffering=1)
    with tqdm(total=len(devset_gen), ncols=70) as pbar:
        for batch_index, (m_batch, m_label) in enumerate(devset_gen):
            n_iter = epoch * len(devset_gen) + batch_index
            m_batch, m_label = m_batch.to(device), m_label.to(device)
            embeddings, output = model(m_batch)
            CE_loss = criterion['CE_loss'](output, m_label)
            AAMsoftmax_loss = criterion['AAMsoftmax_loss'](embeddings, m_label) 
            AMsoftmax_loss = criterion['AMsoftmax_loss'](embeddings, m_label)
            Center_loss = criterion['Center_loss'](embeddings, m_label)
            alpha = 0.6
            lam_bda = 0.2
            # loss = CE_loss
            # loss = alpha*CE_loss + (1-alpha)*Center_loss
            # loss = CE_loss + lam_bda*Center_loss
            loss =AAMsoftmax_loss
            # loss = AMsoftmax_loss
            # loss = Center_loss
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            pbar.set_description('epoch: %d, loss:%.3f' % (epoch, loss))
            pbar.update(1)
            if args.do_lr_decay:
                if args.lr_decay == 'keras':
                    lr_scheduler.step()
            tb_writer.add_scalars('Train loss', {'Loss': loss.data.item()}, n_iter)
            f_loss.write('epoch:%d, train_loss:%.4f\n' % (epoch, loss))
    f_loss.close()
    

def evaluate_model(model, evalset_gen, eval_trial_txt, cat_paths, save_dir, epoch, device):
    model.eval()
    tb_writer = SummaryWriter('./log')
    with torch.set_grad_enabled(False):
        l_cat_embeddings = []
        with tqdm(total=len(evalset_gen), ncols=70) as pbar:
            for m_batch in evalset_gen:
                m_batch = m_batch.to(device) 
                code = model(x=m_batch, is_test=True)
                l_cat_embeddings.extend(code.cpu().numpy())
                pbar.update(1)
        d_embeddings = {}
        if not len(cat_paths) == len(l_cat_embeddings):   # cat_paths示例：
            print('cat_paths和l_cat_embeddings數量不一致')
            exit()
        for k, v in zip(cat_paths, l_cat_embeddings):
            d_embeddings[k] = v
## 第二步，计算EER
        y_label = []
        y_score = []
        f_res = open(save_dir+'results/eval_epoch_{}.txt'.format(epoch), 'w')
        for line in eval_trial_txt:
            trg, cat_utt_face_a, cat_utt_face_b = line.strip().split(' ')
            y_label.append(int(trg))  # 1或0
            y_score.append(cos_sim(d_embeddings[cat_utt_face_a], d_embeddings[cat_utt_face_b]))
            f_res.write('{score} {target}\n'.format(score=y_score[-1],target=y_label[-1]))
        f_res.close()
        eer = tuneThresholdfromScore(y_score, y_label, [1, 0.1])[1]
        fnrs, fprs, thresholds = ComputeErrorRates(y_score, y_label)
        minDCF, _ = ComputeMinDcf(fnrs, fprs, thresholds, 0.05, 1, 1)
    return eer, minDCF
