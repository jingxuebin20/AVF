### Model architecture
本项目的人脸特征采用Facenet模型提取，声纹特征采用ECAPA-TDNN模型提取。

### Datasets
1.   数据集采用Voxceleb1 dev set作为训练集，Voxceleb1 test、NIST SRE19多媒体数据集和CNC-AV作为测试集。  
2.   Face embeddings可在'DB/face/emb/'获取。
其中vox1_face_D_embedding.npy和vox1_face_T_embedding.npy分别是Voxcelev1训练集和测试集中关于人员人脸特征的embeddings（512维）。vox1_face_D_label.txt和vox1_face_T_label.txt为对应的label list，如：[id10001/1zcIwhmdeo4/0000375.jpg,id10001/1zcIwhmdeo4/0000475.jpg,...]。)）
3.   Speaker embeddings可在'DB/wav/emb/'获取。
其中TTA_vox1_dev.pk和TTA_vox1_eval.pk分别是Voxcelev1训练集和测试集中关于人员语音特征的embeddings。它是一个字典格式的文件，keys为Speaker id，如'id10001/1zcIwhmdeo4/00001.wav'，values为对应的embeddings（1024维）。

### Usage
1.    数据预处理：Run data_preprocess.py
2.    模型训练：Run trainning_AVN.py
3.    模型评估：Run evaluation_model.py
