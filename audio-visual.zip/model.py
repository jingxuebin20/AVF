import torch
import torch.nn as nn
import torch.nn.functional as F



class Gated_Feature_Fusion(nn.Module):
    def __init__(self, d_args):
        super(Gated_Feature_Fusion, self).__init__()
        # DNNs
        self.fc_a = nn.Linear(in_features=192, out_features=512)  # 192,512
        self.fc_v = nn.Linear(in_features=512, out_features=512)  # 512, 512
        self.fc_att = nn.Linear(in_features=704, out_features=512)  # 704,512
        self.fc_out = nn.Linear(in_features=d_args['nb_space_node'], out_features=d_args['nb_classes']) # 1024, 1211/5994
        # BatchNormalizer
        self.bn_a = nn.BatchNorm1d(192)
        self.bn_v = nn.BatchNorm1d(512)
        self.bn_cat = nn.BatchNorm1d(704)
        # Dropout
        self.dropout = torch.nn.Dropout(0.5)
        # loss
        self.LogSoftmax = nn.LogSoftmax(dim=1)  # LogSoftmax与nn.NLLLoss()结合使用,求交叉熵损失

    def forward(self, x, is_test=False):
        x_cat = x  # x_cat.size() 是 torch.Size([64, 704])  # 以batch size为64为例
        # print('x_cat',x_cat.size())
        x_a = x[:, 0:192]  # x_a.size() 是 torch.Size([64, 192])
        # print('x_a',x_a.size())
        x_v = x[:, 192:]  # x_v.size() 是 torch.Size([64, 512])
        # print('x_v', x_v.size())
        # Batch Normalization操作
        if not is_test:
            x_a = self.bn_a(x_a)# x_a.size() 是 torch.Size([64, 192])
            # print('x_a1', x_a.size())
            x_v = self.bn_v(x_v)# x_v.size() 是 torch.Size([64, 512])
            # print('x_v1', x_v.size())
            x_cat = self.bn_cat(x_cat)# x_cat.size() 是 torch.Size([64, 704])
            # print('x_cat1', x_cat.size())
        # 定义各自的全连接层
        x_A = self.fc_a(x_a)
        # print('x_A', x_A.size())
        x_V = self.fc_v(x_v)
        # print('x_V', x_V.size())
        x_Cat = self.fc_att(x_cat)
        # print('x_Cat', x_Cat.size())
        # dropout操作
        x_A = self.dropout(x_A)
        # print('x_A1', x_A.size())
        x_V = self.dropout(x_V)
        # print('x_V1', x_V.size())
        x_Cat = self.dropout(x_Cat)
        # print('x_Cat1', x_Cat.size())
        # activation操作
        h_a = torch.tanh(x_A)
        # print('h_a',h_a.size())
        h_v = torch.tanh(x_V)
        # print('h_v', h_v.size())
        z = torch.sigmoid(x_Cat)   # z.size() 是 torch.Size([64, 1024])
        # print('z', z.size())
        # gate組合
        E_p = torch.mul(z,h_a) + torch.mul(1-z,h_v)  # 维度是1024
        # print('E_p', E_p.size())
        if not is_test:
            E_p  = self.bn_v(E_p)    #  加上这一行还是有效果
            # print('E_p1', E_p.size())
        embedding = E_p.view(E_p.size(0),-1)
        # 对于test，则不需要经过最后一层全连接层（输出层），在这里直接得到person embedding
        if is_test:
            return embedding
        output = self.fc_out(embedding)      # 输入embedding维度为1024，输出out维度为 1211 / 5994
        # print('output', output.size())
        # output = self.LogSoftmax(output)   # 计算LogSoftmax，后面还需要加NLLLoss
        return embedding, output

class Attention_Feature_Fusion(nn.Module):
    def __init__(self, d_args):
        super(Attention_Feature_Fusion, self).__init__()
        # DNNs
        self.fc_a = nn.Linear(in_features=192, out_features=512)  # 192,512
        self.fc_v = nn.Linear(in_features=512, out_features=512)  # 512,512
        self.attention = nn.Linear(in_features=704, out_features=512)  # 704,512
        self.fc_out = nn.Linear(in_features=d_args['nb_space_node'], out_features=d_args['nb_classes']) # 512, 1211/5994
        # Batch Normalizer
        self.bn_a = nn.BatchNorm1d(192)
        self.bn_v = nn.BatchNorm1d(512)
        self.bn_cat = nn.BatchNorm1d(704)
        # Dropout
        self.dropout = torch.nn.Dropout(0.5)  # 设为0.5最优
        # loss
        self.LogSoftmax = nn.LogSoftmax(dim=1)  # LogSoftmax与nn.NLLLoss()结合使用,求交叉熵损失
        self.Softmax = nn.Softmax(dim=1)        # dim=1表示对每一行的所有元素进行softmax，并使得每一行所有元素和为1

    def forward(self, x, is_test=False):
        x_cat = x             # x_cat.size() 是 torch.Size([64, 1536])  # 以batch size为64为例
        x_a = x[:, 0:192]  # x_a.size() 是 torch.Size([64, 1024])
        x_v = x[:, 192:]  # x_v.size() 是 torch.Size([64, 512])
        # Batch Normalization操作
        if not is_test:
            x_a = self.bn_a(x_a)
            x_v = self.bn_v(x_v)
            x_cat = self.bn_cat(x_cat)
        # 定义各自的全连接层
        x_A = self.fc_a(x_a)
        x_V = self.fc_v(x_v)
        score = self.attention(x_cat)
        # dropout操作
        x_A = self.dropout(x_A)
        x_V = self.dropout(x_V)
        # attention score 计算
        att_score = self.Softmax(score)  # 进行归一化  # torch.Size([64, 2])
        score_a = att_score[:, 0]                    # torch.Size([64])
        score_b = att_score[:, 1]
        att_score_a = score_a.detach().unsqueeze(dim=1).repeat(1, 512)  # torch.Size([64, 512])
        att_score_b = score_b.detach().unsqueeze(dim=1).repeat(1, 512)
        E_p = torch.mul(x_A, att_score_a) + torch.mul(x_V, att_score_b) # torch.Size([64, 512])
        if not is_test:
            E_p  = self.bn_v(E_p)
        embedding = E_p.view(E_p.size(0),-1)
        if is_test:
            return embedding
        output = self.fc_out(embedding)   # 输入的embedding维度为1024，输出的维度为1211 / 5994
        return embedding, output

class Inter_Attention_Feature_Fusion(nn.Module):
    def __init__(self, d_args):
        super(Inter_Attention_Feature_Fusion, self).__init__()
        # DNNs
        self.fc_a = nn.Linear(in_features=192, out_features=512)  # 192，512
        self.fc_v = nn.Linear(in_features=512, out_features=512)  # 512,512
        self.attention = nn.Linear(in_features=704, out_features=512)  # 704，512
        self.fc_out = nn.Linear(in_features=d_args['nb_space_node'], out_features=d_args['nb_classes']) # 1024, 1211/5994
        # Batch Normalizer
        self.bn_a = nn.BatchNorm1d(192)
        self.bn_v = nn.BatchNorm1d(512)
        self.bn_cat = nn.BatchNorm1d(704)
        # Dropout
        self.dropout = torch.nn.Dropout(0.5)  # 设为0.5最优
        # loss
        self.LogSoftmax = nn.LogSoftmax(dim=1)  # LogSoftmax与nn.NLLLoss()结合使用,求交叉熵损失
        self.Softmax = nn.Softmax(dim=1)        # dim=1表示对每一行的所有元素进行softmax，并使得每一行所有元素和为1

    def forward(self, x, is_test=False):
        x_cat = x             # x_cat.size() 是 torch.Size([64, 1536])  # 以batch size为64为例
        x_a = x[:, 0:192]  # x_a.size() 是 torch.Size([64, 1024])
        x_v = x[:, 192:]  # x_v.size() 是 torch.Size([64, 512])
        # Batch Normalization操作
        if not is_test:
            x_a = self.bn_a(x_a)
            x_v = self.bn_v(x_v)
            x_cat = self.bn_cat(x_cat)
        # 定义各自的全连接层
        Q1 = self.fc_a(x_a)
        Q2 = self.fc_v(x_v)
        V = self.attention(x_cat)

        Ua1 = torch.mul(Q1, V)
        Ua2 = torch.mul(Q2, V)
        Ua1 = self.dropout(Ua1)
        Ua2 = self.dropout(Ua2)
        Ua11 = torch.mul(Ua1, V) + Q1
        Ua22 = torch.mul(Ua2, V) + Q2
        Ua11 = self.dropout(Ua11)
        Ua22 = self.dropout(Ua22)
        embedding = self.dropout(Ua11 + Ua22)
        if not is_test:
            embedding  = self.bn_v(embedding)
        embedding = embedding.view(embedding.size(0),-1)
        if is_test:
            return embedding
        output = self.fc_out(embedding)   # 输入的embedding维度为1024，输出的维度为1211 / 5994
        return embedding, output

class Concat_Feature_Fusion(nn.Module):
    def __init__(self, d_args):
        super(Concat_Feature_Fusion, self).__init__()
        self.fc = nn.Linear(in_features=d_args['cat_emb_dim'], out_features=d_args['nb_fc1_node'])  # 704, 512
        self.fc_out = nn.Linear(in_features=d_args['nb_fc1_node'], out_features=d_args['nb_classes']) # 512, 1211/5994
        self.dropout = torch.nn.Dropout(p=0.7,inplace=True)    # 设为0.7最佳
        self.LogSoftmax = nn.LogSoftmax(dim=1)  # LogSoftmax与nn.NLLLoss()结合使用,求交叉熵损失

    def forward(self, x, is_test=False):
        x = self.fc(x)  # 输入的cat嵌入向量的维度是704，输出512
        # print("x1",x.size())#([64,512])
        x = self.dropout(x)
        x = F.relu(x)
        embedding = x.view(x.size(0),-1)
        if is_test:
            return embedding
        output = self.fc_out(embedding)   # input 512, output 1211/5994
        # print("output", output.size())#([64,1211])
        return embedding, output

###Gated_all_Feature_Fusion是三种及三种以上的模态采用这种门控多模态融合单元
class Gated_all_Feature_Fusion(nn.Module):
    def __init__(self, d_args):
        super(Gated_all_Feature_Fusion, self).__init__()
        # DNNs
        self.fc_a = nn.Linear(in_features=192, out_features=512)  # 192,512
        self.fc_v = nn.Linear(in_features=512, out_features=512)  # 512, 512
        self.fc_att = nn.Linear(in_features=704, out_features=512)  # 704,512
        self.fc_out = nn.Linear(in_features=d_args['nb_space_node'], out_features=d_args['nb_classes']) # 512, 1211
        # BatchNormalizer
        self.bn_a = nn.BatchNorm1d(192)
        self.bn_v = nn.BatchNorm1d(512)
        self.bn_cat = nn.BatchNorm1d(704)
        # Dropout
        self.dropout = torch.nn.Dropout(0.5)
        # loss
        self.LogSoftmax = nn.LogSoftmax(dim=1)  # LogSoftmax与nn.NLLLoss()结合使用,求交叉熵损失

    def forward(self, x, is_test=False):
        x_cat = x  # x_cat.size() 是 torch.Size([64, 704])  # 以batch size为64为例
        x_a = x[:, 0:192]  # x_a.size() 是 torch.Size([64, 192])
        x_v = x[:, 192:]  # x_v.size() 是 torch.Size([64, 512])
        # print('x_v', x_v.size())

        # Batch Normalization操作
        if not is_test:
            x_a = self.bn_a(x_a)# x_a.size() 是 torch.Size([64, 192])
            x_v = self.bn_v(x_v)# x_v.size() 是 torch.Size([64, 512])
            x_cat = self.bn_cat(x_cat)# x_cat.size() 是 torch.Size([64, 704])
        # 定义各自的全连接层
        x_A = self.fc_a(x_a)
        x_V = self.fc_v(x_v)
        x_Cat = self.fc_att(x_cat)
        # dropout操作
        x_A = self.dropout(x_A)
        x_V = self.dropout(x_V)
        x_Cat = self.dropout(x_Cat)
        # activation操作
        h_a = torch.tanh(x_A)
        print('h_a',h_a.size())
        h_v = torch.tanh(x_V)
        print('h_v', h_v.size())
        h_Cat = torch.tanh(x_Cat)
        print('h_Cat', h_Cat.size())
        # print('h_v', h_v.size())
        z_a = torch.sigmoid(x_A)
        print('z_a', z_a.size())
        z_v = torch.sigmoid(x_V)
        print('z_v', z_v.size())
        z_Cat = torch.sigmoid(x_Cat)   # z.size() 是 torch.Size([64, 1024])
        print('z_Cat', z_Cat.size())
        # print('z', z.size())
        # gate組合
        E_a = torch.mul(z_a,h_a)
        print('E_a',E_a.size())
        E_v = torch.mul(z_v, h_v)
        print('E_v', E_v.size())
        E_Cat = torch.mul(z_Cat, h_Cat)
        print('E_Cat', E_Cat.size())
        E_p = E_a+E_v+E_Cat  # 维度是1024
        # print('E_p', E_p.size())
        if not is_test:
            E_p  = self.bn_v(E_p)    #  加上这一行还是有效果
            # print('E_p1', E_p.size())
        embedding = E_p.view(E_p.size(0),-1)
        # 对于test，则不需要经过最后一层全连接层（输出层），在这里直接得到person embedding
        if is_test:
            return embedding
        output = self.fc_out(embedding)      # 输入embedding维度为1024，输出out维度为 1211 / 5994
        # print('output', output.size())
        # output = self.LogSoftmax(output)   # 计算LogSoftmax，后面还需要加NLLLoss
        return embedding, output

class Only_Voice_Feature(nn.Module):
    def __init__(self, d_args):
        super(Only_Voice_Feature, self).__init__()
        self.fc = nn.Linear(in_features=192, out_features=192)  # 192, 192
        self.fc_out = nn.Linear(in_features=192, out_features=d_args['nb_classes'])  # 1024, 1211/5994
        self.bn = nn.BatchNorm1d(192)
        self.dropout = torch.nn.Dropout(0.5)

    def forward(self, x, is_test=False):
        x_a = x[:, 0:192]  # x_a.size() 是 torch.Size([64, 192]) 语音嵌入为19维
        if not is_test:
            x_a = self.bn(x_a)  # Batch Normalization
        x_a = self.fc(x_a)
        x_a = self.dropout(x_a)
        x_a = F.relu(x_a)
        embedding = x_a.view(x_a.size(0), -1)
        if is_test:
            return embedding
        output = self.fc_out(embedding)  # input 1024, output 1211/5994
        return embedding, output

class Only_Fcae_Feature(nn.Module):
    def __init__(self, d_args):
        super(Only_Fcae_Feature, self).__init__()
        self.fc = nn.Linear(in_features=512, out_features=512)  # 512, 512
        self.fc_out = nn.Linear(in_features=512, out_features=d_args['nb_classes'])  # 512, 1211/5994
        self.bn = nn.BatchNorm1d(512)
        self.dropout = torch.nn.Dropout(0.5)

    def forward(self, x, is_test=False):
        x_v = x[:, 192:]  # x_v.size() 是 torch.Size([64, 512])  图像嵌入为512维
        if not is_test:
            x_v = self.bn(x_v)  # Batch Normalization
        x_v = self.fc(x_v)
        x_v = self.dropout(x_v)
        x_v = F.relu(x_v)
        embedding = x_v.view(x_v.size(0), -1)
        if is_test:
            return embedding
        output = self.fc_out(embedding)  # input 1024, output 1211/5994
        return embedding, output