import argparse
import numpy as np
import os
import torch
import torch.nn as nn
from loss import *

def str2bool(v):
    if isinstance(v, bool):
       return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
def get_args():
    parser = argparse.ArgumentParser()
    # dir
    parser.add_argument('-save_dir', type=str, default='DNNs/')
    parser.add_argument('-wav1_dev', type=str, default='/mnt/database/sre/voxceleb/1/dev/')      #  即vox1的dev set用作train
    parser.add_argument('-wav1_test', type=str, default='/mnt/database/sre/voxceleb/1/test/wav/')    #  即vox1的test集用作test
    parser.add_argument('-wav1_emb', type=str, default='DB/wav/emb/')
    parser.add_argument('-face1_dev', type=str, default='/mnt/workspace/to_be_delete/SRE19/multimedia/LDC2019E55_png/vox1/dev/')
    parser.add_argument('-face1_test', type=str, default='/mnt/workspace/to_be_delete/SRE19/multimedia/LDC2019E55_png/vox1/test/')
    parser.add_argument('-face1_emb', type=str, default='DB/face/emb/')

    parser.add_argument('-nb_D_embd_samples', type=int, default=80000)
    parser.add_argument('-nb_valid_trial', type=int, default=20000)
    parser.add_argument('-nb_eval_trial', type=int, default=20000)
    parser.add_argument('-epoch', type=int, default=60)
    parser.add_argument('-train_bs', type=int, default=64)
    parser.add_argument('-valid_bs', type=int, default=32)
    parser.add_argument('-eval_bs', type=int, default=100)
    parser.add_argument('-lr', type = float, default=0.001)
    parser.add_argument('-lr_decay', type=str, default='keras')
    parser.add_argument('-weight_decay', type=float, default=0.0001)
    parser.add_argument('-optimizer', type=str, default='Adam')
    parser.add_argument('-nb_worker', type=int, default=8)
    parser.add_argument('-seed', type=int, default=1234)
    # parser.add_argument('-load_model_dir', type=str, default='')
    # parser.add_argument('-load_model_opt_dir', type=str, default='')
    # DNN args
    parser.add_argument('-m_cat_emb_dim', type=int, default=704)  # 人脸512+语音192 = 704
    parser.add_argument('-m_nb_fc1_node', type=int, default=512)
    parser.add_argument('-m_nb_space_node', type=int, default=512)
    parser.add_argument('-m_nb_classes',  type=int, default=1211)
    # flag
    parser.add_argument('-amsgrad', type=str2bool, nargs='?', const=True, default=True)
    parser.add_argument('-make_val_trial', type=str2bool, nargs='?', const=True, default=False)
    parser.add_argument('-save_best_only', type=str2bool, nargs='?', const=True, default=False)
    parser.add_argument('-load_model', type=str2bool, nargs='?', const=True, default=False)
    parser.add_argument('-do_lr_decay', type=str2bool, nargs='?', const=True, default=True)
    parser.add_argument('-mg', type=str2bool, nargs='?', const=True, default=False)
    parser.add_argument('-reproducible', type=str2bool, nargs='?', const=True, default=True)
    ## 3、解析参数
    args = parser.parse_args()
    args.model = {}
    for k, v in vars(args).items():
        if k[:2] == 'm_':
            args.model[k[2:]] = v
    return args






